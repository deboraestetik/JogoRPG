package JogoRPG;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

// Jogo desenvolvido na matéria de Projeto Intregador do 1º semestre do curso de TADS do Senac Santo Amaro

// - Débora Ramos Teixeira Souza


public class JogoRPG {
	
    static Scanner input = new Scanner(System.in);
    static String nomeJogador;
    
    public static void main(String[] args) {
        int opcaoMenu;
        cabecalhoMtk();
        opcaoMenu = menu();
        if (opcaoMenu == 2) {
        }
    }
    
    static void cabecalhoMtk() {
        System.out.println("");
        System.out.println("MMMMMMMM               MMMMMMMM   TTTTTTTTTTTTTTTTTTTTTTT   KKKKKKKKK    KKKKKKK");
        System.out.println("M:::::::M             M:::::::M   T:::::::::::::::::::::T   K:::::::K    K:::::K");
        System.out.println("M::::::::M           M::::::::M   T:::::::::::::::::::::T   K:::::::K    K:::::K");
        System.out.println("M:::::::::M         M:::::::::M   T:::::TT:::::::TT:::::T   K:::::::K   K::::::K");
        System.out.println("M::::::::::M       M::::::::::M   TTTTTT  T:::::T  TTTTTT   KK::::::K  K:::::KKK");
        System.out.println("M:::::::::::M     M:::::::::::M           T:::::T             K:::::K K:::::K   ");
        System.out.println("M:::::::M::::M   M::::M:::::::M           T:::::T             K::::::K:::::K    ");
        System.out.println("M::::::M M::::M M::::M M::::::M           T:::::T             K:::::::::::K     ");
        System.out.println("M::::::M  M::::M::::M  M::::::M           T:::::T             K:::::::::::K     ");
        System.out.println("M::::::M   M:::::::M   M::::::M           T:::::T             K::::::K:::::K    ");
        System.out.println("M::::::M    M:::::M    M::::::M           T:::::T             K:::::K K:::::K   ");
        System.out.println("M::::::M     MMMMM     M::::::M           T:::::T           KK::::::K  K:::::KKK");
        System.out.println("M::::::M               M::::::M         TT:::::::TT         K:::::::K   K::::::K");
        System.out.println("M::::::M               M::::::M         T:::::::::T         K:::::::K    K:::::K");
        System.out.println("M::::::M               M::::::M         T:::::::::T         K:::::::K    K:::::K");
        System.out.println("MMMMMMMM               MMMMMMMM         TTTTTTTTTTT         KKKKKKKKK    KKKKKKK");
    }
    
    static int menu() {
        int opcao;
        do {
            System.out.println("");
            System.out.println("### MENU ###");
            System.out.println("1) Instruções");
            System.out.println("2) Jogar");
            System.out.println("3) Créditos");
            System.out.println("4) Sair");
            System.out.print("Escolha uma opção: ");
            opcao = input.nextInt();
            switch (opcao) {
                case 1:
                    instrucoes();
                    break;
                case 2:
                    menuJogar(opcao);
                    String personagem = personagens();
                    int primeira = primeiraFase(1, personagem);
                    int segundaFase = segundafaseAle(primeira);
                    if (segundaFase == 1) {
                        estagiario(personagem);
                    } else if (segundaFase == 2) {
                        CaminhoAnalistaJ(personagem);
                    } else if (segundaFase == 3) {
                        caminhoAnalistaP(personagem);
                    }
                    break;
                case 3:
                    menuCreditos();
                    break;
                case 4:
                    System.out.println("Você escolheu a opção **SAIR**");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 4);
        return opcao;
    }
    
    static void instrucoes() {
    	System.out.println("");
        System.out.println("*** INSTRUÇÕES ***");
        System.out.println("Escolha um dos 3 personagens para inicar o jogo. Você terá que concluir as fases propostas para vencer,");
        System.out.println("cada fase é composta por exercícios voltados para a matéria de Matemática Para Tecnlogia da Informação.");
        System.out.println("\n>>> Como jogar <<<");
        System.out.println("Use sempre os números ou letras propostos para escolher a opção/alternativa correta e pressione 'Enter' para seguir no jogo.");
        System.out.println("Exemplo: 1 para continuar ou 2 para sair ou a, b, c, d ou e em cada exercício para escolher a alternativa correta.");
        System.out.println("\n>>> Objetivo do jogo <<<");
        System.out.println("Concluir todas as fases e ser contratado pela empresa MTK.");
    }

    static void menuCreditos() {
        System.out.println("");
        System.out.println("*** CRÉDITOS ***");
        System.out.println("Jogo desenvolvido na matéria de Projeto Intregador do 1º semestre do curso de TADS do Senac Santo Amaro.");
        System.out.println("Projeto desenvolvido por:\n");
        System.out.println("Andrea Pereira dos Santos");
        System.out.println("Débora Ramos Teixeira");
        System.out.println("Douglas Cardoso Ferreira");
        System.out.println("Leandro Silva de Souza");
    }

    static String personagens() {
    	int per = 0;
    	do {
    		System.out.println("\n>>> Personagens <<<");
            System.out.println("1) CANDIDATO – X");
            System.out.println("-> Tem como característica estar cursando faculdade na área da tecnologia da informação.​");
            System.out.println("--> Ele tem poderes de cabeça fresca, tem estudado muito, e tem a habilidade de estar atualizado.​");
            System.out.println("");
            System.out.println("2) CANDIDATO - EX");
            System.out.println("->Tem como característica ter finalizado uma graduação na área da tecnologia da informação.​");
            System.out.println("--> Ele tem poderes de cabeça cheia, tem todas as informações do curso completo, porém está a 6 meses sem se atualizar.​");
            System.out.println("");
            System.out.println("3) CADIDATO - MX");
            System.out.println("-> Tem como característica ter finalizado uma pós graduação na área da tecnologia da informação.​");
            System.out.println("--> Ele tem poderes de 2 cabeças cheias, porém está a 1 ano sem se atualizar.");
            System.out.println("");
            System.out.print("Escolha uma opção: ");
            per = input.nextInt();
            if(per < 1 || per > 3) {
            	System.out.println("\nOpção inválida!\n"
            			+ "Você precisa escolher um dos 3 personagens!");
            }
    	} while (per < 1 || per > 3);
    	
    	System.out.print("Qual seu nome: ");
        nomeJogador = input.next();
        
        switch (per) {
            case 1:
                return nomeJogador + ", você tem as caracteristicas do CANDIDATO - X";
            case 2:
                return nomeJogador + ", você tem as caracteristicas do CANDIDATO - EX";
            case 3:
                return nomeJogador + ", você tem as caracteristicas do CANDIDATO - MX";
        }
        return null;
    }

    static int menuJogar(int a) {
        switch (a) {
            case 2:
                System.out.println("");
                System.out.println("*** JOGAR ***");
                break;
        }
        return a;
    }

    static int primeiraFase(int m, String per) {
        int opcao, nome, codigo1, i = 1, certo = 0;
        String res1;
        
        System.out.println("");
        System.out.println("SEJA BEM-VINDO A EMPRESA MTK ");
        System.out.println("");
        System.out.println("Estamos no ano de 2040, a MTK é a maior empresa de tecnologia do planeta, amplamente conhecida por ter os melhores profissionais da área de tecnologia e");
        System.out.println("por pagar os maiores salários. Sempre que a MTK abre seu processo seletivo para novos colaboradores muitos rumores vem à tona, pois muito se comenta");
        System.out.println("sobrecomo é esse processo de seleção, alguns dos rumores dizem que literalmente você tem que lutar");
        System.out.println("para passar no processo, o certo é que o processo é totalmente obscuro, pois aqueles que participaram e conseguiram passar, precisam assinar");
        System.out.println("um contrato de confidencialidade com uma gota de sangue, e aqueles outros que fizeram o processo e não passaram, nunca mais foram vistos.");
        
        do {
        	System.out.println("\nSerá que você está a altura desse desafio, se acha capaz de trabalhar na maior empresa do ");
            System.out.println("mundo, acha que tem força para vencer o obscuro processo seletivo?");
            System.out.println("1) Sim\n2) Não");
            System.out.print("Escolha uma opção: ");
            opcao = input.nextInt();
            if (opcao < 1 || opcao > 2) {
            	System.out.println("\nOpção inválida!\n"
            			+ "Escolha a opção 1 ou 2 e aperte 'Enter'!");
            }
        } while (opcao < 1 || opcao > 2);

        if (opcao == 1) {
        	System.out.println("");
            System.out.println("Você acaba de ser convocado para participar do processo seletivo da MTK, eles estão contratando neste processo Estagiário,\n"
            		+ "Analista Junior e Analista Pleno, através do seu desenvolvimento no processo você pode preencher uma das vagas.\n");
            System.out.println("Ao entrar na empresa você se direciona a recepção e logo se depara com 2 robôs onde um deles confirma seus dados.");
            
            do {
            	//pedimos para que o jogador confirme seus dados
            	//neste laço controlamos o possivel erro de o usuario escolher uma opção diferente das possiveis
            	//caso isso aconteça o laço se repete até o usuario escolher uma opção válida
            	System.out.println("\nOlá você é " + per);
                System.out.println("1) Sim\n2) Não");
                System.out.print("Escolha uma opção: ");
                nome = input.nextInt();
            	
                if (nome < 1 || nome > 2) {
                	System.out.print ("\nOpção invalida!\n"
                			+ "Escolha a opção 1 ou 2 e aperte 'Enter'!\n");
                }
            } while (nome < 1 || nome > 2);
            if (nome == 1) {
            	System.out.println("");
                System.out.println("Em seguida um dos robôs te leva até uma sala, você está muito apreensivo porque toda a estrutura do\n"
                		+ "prédio é sombria e vazia e então o pior acontece, o robô te joga na sala, sai e tranca a porta, você tentou lutar\n"
                		+ "mas ele é mais forte você fica com muito medo pois tudo está escuro, e então você ouve uma voz que diz:\n");
                System.out.println("- Olá " + nomeJogador + " você acaba de ser preso, boa sorte para sair vivo ou morrer tentando, você entra em desespero.\n");
                System.out.println("De repente as luzes se ascendem e você vê que está em cima de um pequeno relevo que forma um caminho até uma pilastra");
                System.out.println("você olha em sua volta e vê que no chão abaixo deste relevo tem um monte de bombas explosivas, você olha a sua direita");
                System.out.println("e vê um grande relógio que marca 30 minutos, no momento que você começa a caminhar até está pilastra o relógio dispara é ai que você");
                System.out.println("percebe que precisa fazer algo urgente para parar o relógio e tentar sobreviver.");
                System.out.println("");
                System.out.println("De frente para a pilastra você encontra um tela com a seguinte mensagem:");
                System.out.println("Sr(a) " + nomeJogador + " decifre o código e aparecerá um botão vermelho na parte inferior da pilastra aperte-o e a pilastra irá");
                System.out.println("desaparecer liberando o caminho para você continuar tentando sobreviver, se o relógio zerar todas as bombas irão explodir!");
                do {
                	System.out.println("\nVocê quer decifrar o código?\n1) Sim\n2) Não");
                    System.out.print("Escolha uma opção: ");
                    codigo1 = input.nextInt();
                    if (codigo1 < 1 || codigo1 > 2) {
                    	System.out.print ("\nOpção invalida!\n"
                    			+ "Escolha a opção 1 ou 2 e aperte 'Enter'!\n");
                    }
                } while (codigo1 < 1 || codigo1 > 2);
                if (codigo1 == 1) {
                    do {
                    	ArrayList alternativas = new ArrayList();
                    	
                    	alternativas.add("12"); //resposta correta!
                    	alternativas.add("14");
                    	alternativas.add("15");
                    	alternativas.add("18");
                    	alternativas.add("0");

                    	Collections.shuffle(alternativas);
                    	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                    	System.out.println("");
                        System.out.println("Qual a opção certa para o resultado da expressão numérica [44 + (5 – 3)^2] : (9 – 7)^2");
                        System.out.println("a) " +  alternativas.get(0));
                        System.out.println("b) " +  alternativas.get(1));
                        System.out.println("c) " +  alternativas.get(2));
                        System.out.println("d) " +  alternativas.get(3));
                        System.out.println("e) " +  alternativas.get(4));
                        System.out.print("Escolha uma opção: ");
                        res1 = input.next();
                        
                        //após a escolha da resposta, testamos caso por caso, para saber se a alternativa escolhida está correta!
                        switch (res1) {
                            case "a":
                            case "A":
                            	if (alternativas.get(0).equals("12")) {
                            		certo = 1;
                            		}
                                break;
                            case "b":
                            case "B":
                            	if (alternativas.get(1).equals("12")) {
                            		certo = 1;
                            		}
                                break;
                            case "c":
                            case "C":
                            	if (alternativas.get(2).equals("12")) {
                            		certo = 1;
                            		}
                                break;
                            case "d":
                            case "D":
                            	if (alternativas.get(3).equals("12")) {
                            		certo = 1;
                            		}
                                break;
                            case "e":
                            case "E":
                            	if (alternativas.get(4).equals("12")) {
                            		certo = 1;
                            		}
                                break;
                            default:
                                System.out.println("Opção inválida!");
                        }
                        if (i == 1 && certo != 1) {
                        	//se na 1ª tentativa o jogador errar a resposta, damos uma primeira dica, para ajudar na resolução do desafio
                            System.out.println("Alternativa Errada!\n\n"
                            		+ ">>> Dica <<<\n"
                            		+ "1. Resolva primeiro o que está entre parênteses.");
                        } else if (i == 2 && certo != 1) {
                        	//se na 2ª tentativa o jogador errar a resposta, damos mais uma dica, para ajudar na resolução do desafio
                        	 System.out.println("Alternativa Errada!\n\n"
                             		+ ">>> Dica <<<\n"
                             		+ "1. Resolva primeiro o que está entre parênteses.\n"
                             		+ "2. Depois resolva as potências.");
                        }
                        i++;
                    } while (i <= 3 && certo != 1);
                    if (certo != 1) {
                    	//se após 3 tentativas o jogador errar a resposta, ele acaba morrendo, tendo assim que iniciar novamente o jogo
                        System.out.println("\n(x_x) MORREU (x_x)\n"
                        		+ "" + nomeJogador + " você precisa estudar mais potenciação e expressões númericas.");
                        return 2;
                    } else {
                    	//acertando a resposta em até 3 tentativas, o jogador recebe um feedback elogiando seu conhecimento no conteúdo da matéria
                    	//e é direcionado para próxima fase do jogo
                        System.out.println("\n(^_^) Parabéns (^_^)\n"
                        		+ "" + nomeJogador + " você acertou, está indo muito bem em potenciação e expressões numéricas.\n"
                        		+ "Então o botão vermelho aparece, você o aperta e a pilastra desaparece liberando o caminho.\n"
                        		+ "Você corre e chega até uma porta a abre e se depara com outra sala, a porta rapidamente se fecha\n"
                        		+ "deixando a próxima sala toda escura.\n");
                        return 1;
                    }
                } else {
                	//se o jogador escolher não decifrar o código ele acaba morrendo, tendo assim que iniciar novamente o jogo
                    System.out.println("\n(x_x) MORREU (x_x)\n"
                    		+ "" + nomeJogador + " você escolheu não decifrar o código, o relógio zerou e todas as bombas explodiram!");
                }
                return 2;
            } else {
            	//se o jogador disser que os dados apresetandos não é dele, ele é detectado como intruso, tendo assim que iniciar novamente o jogo
            	System.out.println("\n(-_-) INTRUSO (-_-)\n"
            			+ "Você foi detectado como um intruso e um dos robôs te convidou a se retirar da empresa.");
            	return 2;
            }
        } else {
        	//se o jogador escolher não iniciar o jogo, apresentamos uma mensagem, tentando o instigar a jogador novamente e inicia o desafio do jogo
            System.out.println("\n(+_+) FRACO (+_+)\n"
            		+ "" + nomeJogador + " você foi considerado inadequado e não está a altura de ser um dos colaboradores da MTK.");
        }
        return 2;
    }

    static int segundafaseAle(int n) {
        if (n == 1) {
            int porta, portaEscolhida, i = 1, j = 1, k = 1, certo = 0, certo2 = 0, certo3 = 0;
            String res1, res2, res3;
            Random aleatorio = new Random();
            porta = aleatorio.nextInt(3) + 1;
            System.out.println("Então de repente as luzes se ascendem e você se depara com 3 três portas, na frente de cada porta tem 1 código a ser decifrado,");
            System.out.println("quando você chega mais próximo sem perceber você passa por uma luz infravermelha e uma sirene é acionada e você percebe que a sala");
            System.out.println("está se enchendo de água, e em poucos minutos você vai morrer afogado. Você precisa urgentemente decifrar ");
            System.out.println("o código de alguma das portas para sair o mais rápido possível desta sala.");
            do {
                System.out.println("\nEscolha uma das portas para decifrar o código: ");
                System.out.println("1) Cinza");
                System.out.println("2) Preta");
                System.out.println("3) Branca");
                System.out.print("Escolha uma opção: ");
                portaEscolhida = input.nextInt();

                if (portaEscolhida < 1 || portaEscolhida > 3) {
                    System.out.println("\nVocê deve escolher a Porta 1, 2 ou 3!");
                }
            } while (portaEscolhida < 1 || portaEscolhida > 3);
            // se o número escolhido for diferente de 1,2,3 ele retorna a opção.
            // a aleatoriedade não é feita através da escolha do usuário mas através do Random porta, e ele retorna o valor
            // que foi escolhido em qualquer das opções escolhidas.
            
            if (portaEscolhida == 1) {
                do {
                	ArrayList alternativas = new ArrayList();
                	
                	alternativas.add("1"); //resposta correta!
                	alternativas.add("3");
                	alternativas.add("4");
                	alternativas.add("8");
                	alternativas.add("10");

                	Collections.shuffle(alternativas);
                	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                	System.out.println("");
                    System.out.println("Encontre valor de X na equação 4x + 2 = 8 - 2x");
                    System.out.println("a) " +  alternativas.get(0));
                    System.out.println("b) " +  alternativas.get(1));
                    System.out.println("c) " +  alternativas.get(2));
                    System.out.println("d) " +  alternativas.get(3));
                    System.out.println("e) " +  alternativas.get(4));
                    System.out.print("Escolha uma opção: ");
                    res1 = input.next();
                    
                    //após a escolha da resposta, testamos caso por caso, para saber se a alternativa escolhida está correta!
                    switch (res1) {
                    case "a":
                    case "A":
                    	if (alternativas.get(0).equals("1")) {
                    		certo = 1;
                    		}
                        break;
                    case "b":
                    case "B":
                    	if (alternativas.get(1).equals("1")) {
                    		certo = 1;
                    		}
                        break;
                    case "c":
                    case "C":
                    	if (alternativas.get(2).equals("1")) {
                    		certo = 1;
                    		}
                        break;
                    case "d":
                    case "D":
                    	if (alternativas.get(3).equals("1")) {
                    		certo = 1;
                    		}
                        break;
                    case "e":
                    case "E":
                    	if (alternativas.get(4).equals("1")) {
                    		certo = 1;
                    		}
                        break;
                        default:
                            System.out.println("\nOpção inválida!");
                    }
                    if (i == 1 && certo != 1) {
                        System.out.println("\nAlternativa Errada!\n\n"
                        		+ ">>> Dica <<<\n"
                        		+ "1. Separe os elementos variáveis dos elementos constantes.");
                    } else if (i == 2 && certo != 1) {
                    	System.out.println("\nAlternativa Errada!\n\n"
                        		+ ">>> Dica <<<\n"
                        		+ "1. Separe os elementos variáveis dos elementos constantes.\n"
                        		+ "2. Some ou subtraia os elementos iguais, e descubra valor de X.");
                    }
                    i++;
                } while (i <= 3 && certo != 1);
                if (certo != 1) {
                	System.out.println("\n(x_x) MORREU (x_x)\n"
                			+ "" + nomeJogador + " você precisa estudar mais equação de 1º Grau.");
                    return 10;
                } else {
                	System.out.println("\n(^_^) PARABÉNS (^_^)\n"
                			+ "" + nomeJogador + " você tem um grande conhecimento em equação de 1º Grau.\n");
                    return porta;
                }
            } else if (portaEscolhida == 2) {
                do {
                	ArrayList alternativas = new ArrayList();
                	
                	alternativas.add("2,5");
                	alternativas.add("3,5"); //resposta correta!
                	alternativas.add("6");
                	alternativas.add("8,5");
                	alternativas.add("12");

                	Collections.shuffle(alternativas);
                	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                	System.out.println("");
                    System.out.println("Encontre valor de X na equação 4(x-3) = 2x - 5");
                    System.out.println("a) " +  alternativas.get(0));
                    System.out.println("b) " +  alternativas.get(1));
                    System.out.println("c) " +  alternativas.get(2));
                    System.out.println("d) " +  alternativas.get(3));
                    System.out.println("e) " +  alternativas.get(4));
                    System.out.print("Escolha uma opção: ");
                    res2 = input.next();                    
                    //após a escolha da resposta, testamos caso por caso, para saber se a alternativa escolhida está correta!
                    switch (res2) {
                    case "a":
                    case "A":
                    	if (alternativas.get(0).equals("3,5")) {
                    		certo2 = 1;
                    		}
                        break;
                    case "b":
                    case "B":
                    	if (alternativas.get(1).equals("3,5")) {
                    		certo2 = 1;
                    		}
                        break;
                    case "c":
                    case "C":
                    	if (alternativas.get(2).equals("3,5")) {
                    		certo2 = 1;
                    		}
                        break;
                    case "d":
                    case "D":
                    	if (alternativas.get(3).equals("3,5")) {
                    		certo2 = 1;
                    		}
                        break;
                    case "e":
                    case "E":
                    	if (alternativas.get(4).equals("3,5")) {
                    		certo2 = 1;
                    		}
                        break;
                        default:
                            System.out.println("\nOpção inválida!");
                    }
                    if (j == 1 && certo2 != 1) {
                        System.out.println("\nAlternativa Errada!\n\n"
                        		+ ">>> Dica <<<\n"
                        		+ "1. Separe os elementos variáveis dos elementos constantes.");
                    } else if (j == 2 && certo2 != 1) {
                    	System.out.println("\nAlternativa Errada!\n\n"
                        		+ ">>> Dica <<<\n"
                        		+ "1. Separe os elementos variáveis dos elementos constantes.\n"
                        		+ "2. Some ou subtraia os elementos iguais, e descubra valor de X.");
                    }
                    j++;
                } while (j <= 3 && certo2 != 1);
                if (certo2 != 1) {
                	System.out.println("\n(x_x) MORREU (x_x)\n" + nomeJogador + " você precisa estudar mais equação de 1º Grau.");
                    return 10;
                } else {
                	System.out.println("");
                	System.out.println("\n(*_*) PARABÉNS (*_*)\n"
                			+ "" + nomeJogador + " você tem um grande conhecimento em equação de 1º Grau.\n");
                    return porta;
                }
            } else if (portaEscolhida == 3) {
                do {
                	ArrayList alternativas = new ArrayList();
                	
                	alternativas.add("16");
                	alternativas.add("22");
                	alternativas.add("32");
                	alternativas.add("40"); //resposta correta!
                	alternativas.add("55");

                	Collections.shuffle(alternativas);
                	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                	System.out.println("");
                    System.out.println("Encontre valor de X na equação 3x - 10 = x + 70");
                    System.out.println("a) " +  alternativas.get(0));
                    System.out.println("b) " +  alternativas.get(1));
                    System.out.println("c) " +  alternativas.get(2));
                    System.out.println("d) " +  alternativas.get(3));
                    System.out.println("e) " +  alternativas.get(4));
                    System.out.print("Escolha uma opção: ");
                    res3 = input.next();                    
                    //após a escolha da resposta, testamos caso por caso, para saber se a alternativa escolhida está correta!
                    switch (res3) {
                    case "a":
                    case "A":
                    	if (alternativas.get(0).equals("40")) {
                    		certo3 = 1;
                    		}
                        break;
                    case "b":
                    case "B":
                    	if (alternativas.get(1).equals("40")) {
                    		certo3 = 1;
                    		}
                        break;
                    case "c":
                    case "C":
                    	if (alternativas.get(2).equals("40")) {
                    		certo3 = 1;
                    		}
                        break;
                    case "d":
                    case "D":
                    	if (alternativas.get(3).equals("40")) {
                    		certo3 = 1;
                    		}
                        break;
                    case "e":
                    case "E":
                    	if (alternativas.get(4).equals("40")) {
                    		certo3 = 1;
                    		}
                        break;
                        default:
                            System.out.println("\nOpção inválida!");
                    }
                    if (k == 1 && certo3 != 1) {
                    	System.out.println("\nAlternativa Errada!\n\n"
                        		+ ">>> Dica <<<\n"
                        		+ "1. Separe os elementos variáveis dos elementos constantes.");
                    } else if (k == 2 && certo3 != 1) {
                    	System.out.println("\nAlternativa Errada!\n\n"
                        		+ ">>> Dica <<<\n"
                        		+ "1. Separe os elementos variáveis dos elementos constantes.\n"
                        		+ "2. Some ou subtraia os elementos iguais, e descubra valor de X.");
                    }
                    k++;
                } while (k <= 3 && certo3 != 1);
                if (certo3 != 1) {
                	System.out.println("\n(x_x) MORREU (x_x)\n"
                			+ "" + nomeJogador + " você precisa estudar mais equação de 1º Grau.");
                    return 10;
                } else {
                	System.out.println("\n(*_*) PARABÉNS (*-*)\n"
                			+ "" + nomeJogador + " você tem um grande conhecimento em equação de 1º Grau.\n");
                    return porta;
                }
            }
            return 0;
        }
        return 0;
    }

    static int estagiario(String per) {
        int n1, certo = 0, i = 1, n2;
        String res;
        int vetor[] = {0, 0, -1, 0, 0, 0};
        // vetor de número 2 é o local da bomba
        String vetor1[] = {"(1)_", "(2)_", "(3)_", "(4)_", "(5)_", "(6)_"};
        System.out.println("Você acertou o código e imediatamente a porta é liberada. Você passa correndo pois a sala esta com muita água, passando pela porta\n"
        		+ "rapidamente a mesma se fecha deixando a proxima sala toda escura de repente as luzes se ascendem e você se depara com uma ponte e em volta\n"
        		+ "dela a sala está cheia de água, olhando a sua esquerda você vê o \"ROBORÉ\" uma coisa estranha que se caracteriza como meio robô e meio jacaré,\n"
        		+ "ao dar o primeiro passo você pisaem um botão sem perceber e de repente você percebe que começa a sair água de alguns buracos da sala,\n"
        		+ "fazendo com que você fique muito nervoso pois logo a sala ficará inundada fazendo com que o ROBORÉ te mate.\n");
        System.out.println("Você corre para a ponte e na sua entrada tem um código a ser decifrado e um explicativo");
        System.out.println("*** Decifre o código para saber aonde que tem uma bomba.\n"
        		+ "Caso você não decifre o código você pode arriscar passar pela ponte sem saber aonde a bomba está.***\n"
        		+ "BOA SORTE!");
        do {
        	System.out.println("Você quer decifrar o código?\n1) Sim\n2) Não");
            System.out.print("Escolha uma opção: ");
            n1 = input.nextInt();
            if (n1 < 1 || n1 > 2) {
            	System.out.print ("Opção invalida!\n"
            			+ "Escolha a opção 1 ou 2 e aperte 'Enter'!");
            }
        } while (n1 < 1 || n1 > 2);
        
        if (n1 == 1) {
            do {
            	ArrayList alternativas = new ArrayList();
            	
            	alternativas.add("9"); //resposta correta!
            	alternativas.add("12");
            	alternativas.add("15");
            	alternativas.add("20");
            	alternativas.add("30");

            	Collections.shuffle(alternativas);
            	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
            	System.out.println("");
                System.out.println("Qual o número que você dobra o valor dele, soma 12 ao resultado, divide o novo resultado po 2, e o resultado final é 15?");
                System.out.println("a) " +  alternativas.get(0));
                System.out.println("b) " +  alternativas.get(1));
                System.out.println("c) " +  alternativas.get(2));
                System.out.println("d) " +  alternativas.get(3));
                System.out.println("e) " +  alternativas.get(4));
                System.out.print("Escolha uma opção: ");
                res = input.next();               
                //após a escolha da resposta, testamos caso por caso, para saber se a alternativa escolhida está correta!
                switch (res) {
                case "a":
                case "A":
                	if (alternativas.get(0).equals("9")) {
                		certo = 1;
                		}
                    break;
                case "b":
                case "B":
                	if (alternativas.get(1).equals("9")) {
                		certo = 1;
                		}
                    break;
                case "c":
                case "C":
                	if (alternativas.get(2).equals("9")) {
                		certo = 1;
                		}
                    break;
                case "d":
                case "D":
                	if (alternativas.get(3).equals("9")) {
                		certo = 1;
                		}
                    break;
                case "e":
                case "E":
                	if (alternativas.get(4).equals("9")) {
                		certo = 1;
                		}
                    break;
                    default:
                        System.out.println("\nOpção inválida!");
                }
                if (i == 1 && certo != 1) {
                	System.out.println("\nAlternativa Errada!\n\n"
                    		+ ">>> Dica <<<\n"
                    		+ "1. Tente resolver a questão de traz pra frente.");
                } else if (i == 2 && certo != 1) {
                	System.out.println("\nAlternativa Errada!\n\n"
                    		+ ">>> Dica <<<\n"
                    		+ "1. Tente resolver a questão de traz pra frente.\n"
                    		+ "2. Você também pode testar cada opção no problema, para saber a opção corretar.");
                }
                i++;
            } while (i <= 3 && certo != 1);
            if (certo != 1) {
                System.out.println("\n(x_x) MORREU (x_x)\n"
                		+ "" + nomeJogador + " você precisa estudar mais raciocínio lógico.");
                return 2;
            } else {
            	System.out.println("\n(*_*) PARABÉNS (*-*)\n"
            			+ "" + nomeJogador + " você está indo bem na matéria de raciocínio lógico.\n");
                System.out.println("E então a luz de onde está localizada a bomba se ascende (-1) e você passa correndo pela ponte e pula a bomba.");
                for (int f = 0; f < vetor.length; f++) {
                    System.out.println(vetor[f]);
                }
                System.out.println("Chengando então na porta final você a abre e então você entra em uma outra sala você olha ao\n"
                		+ "seu redor e está em uma sala com vários funcionários trabalhando, cada uma em sua mesa eles te olham também,\n"
                		+ "batem palmas e gritam, parabéns maisum sobrevivente um robô te auxilia até uma sala e diz");
                System.out.println("- Parabéns " + nomeJogador + " você acaba de ser contratado como ESTÁGIARIO, agora preciso de uma gota de sangue sua.");
            }
        } else {
            System.out.println("Você escolheu não decifrar o código!");
            System.out.println("Arrisque passar pela ponte e tente pular o local aonde da bomba");
            for (int j = 0; j < vetor1.length; j++) {
                System.out.println(vetor1[j]);
            }
            System.out.println("\nQual opção você escolhe para pular?");
            System.out.print("Escolha uma opção: ");
            n2 = input.nextInt();

            if (n2 == 3) {
                System.out.println("Parabéns você pulou o local aonde da bomba chengando assim na porta final, você a abre e então você entra em uma outra sala\n"
                		+ "você olha ao seu redor e está em uma sala com vários funcionários trabalhando, cada uma em sua mesa eles te olham também, batem palmas e gritam,\n"
                		+ "parabéns mais um sobrevivente. Um robô te auxilia até uma sala e diz:");
                System.out.println("- Parabéns " + nomeJogador + " você acaba de ser contratado como ESTÁGIARIO, agora preciso de uma gota de sangue sua.");
                return 1;
            } else {
                System.out.println("\n*** BOOOM ***\n"
                		+ "(x_x) MORREU (x_x)\n"
                		+ "" + nomeJogador + " você pulou em cima da bomba!");
                return 2;
            }
        }
        return 0;
    }

    static int CaminhoAnalistaJ(String per) {
    	
        int res1 = 0, res2 = 0, res3 = 0, res4 = 0, ok = 0, ok1 = 0, ok2 = 0, ok4 = 0, ok5 = 0, i1 = 0, i2 = 0, i3 = 0, r = 0, t = 0, t1 = 0;
        String code1, code2, code3, code4, code5;
        //Introdução fase Analista
        System.out.println("Você acertou o código e imediatamente a porta é liberada.\n"
        		+ "Você passa correndo pois a sala esta com muita água, passando pela porta rapidamente a mesma se fecha.");
        System.out.println("Neste momento você está em um lugar totalmente escuro, derrepente ouve um voz:\n");
        System.out.println("- Olá " + nomeJogador + ", você deverá decifrar todos os código propostos para finalizar esta etapa.");
        do {
        	System.out.println("Você está preparado? Quer continuar?\n"
        			+ "1) Sim\n2) Não");
            System.out.print("Escolha uma opção: ");
            res1 = input.nextInt();
            if (res1 < 1 || res1 > 2) {
            	System.out.print ("\nOpção inválida!\n"
            			+ "Escolha a opção 1 ou 2 e aperte 'Enter'!\n");
            }
        } while (res1 < 1 || res1 > 2);
        if (res1 == 1) {
            System.out.println("\nAs luzes se acendem e você se depara com a ROBOBRA. Uma criatura estranha que é meio robo meio cobra.");
            System.out.println("A \"ROBOBRA\" está parada do outro lado da sala. Bloqueando a porta de saída.");
            System.out.println("Você olha para os lados e perceber que na parede a sua direita está escrito: ");
            System.out.println("\n --- Decifre o código da caixa e libere o machado LUZOX, para tentar matar a ROBOBRA ---\n");
            System.out.println("Você se aproxima da caixa onde está o machado e sem perceber passa por uma luz infravermelha que aciona uma sirene");
            System.out.println("então você percebe que as paredes estão se movendo e em pouco tempo, você será esmagado.");
            System.out.println("Você precisa urgentemente liberar o LUZOX e tentar passar pela ROBOBRA");
            do {
            	 System.out.println("\nEntão " + nomeJogador + ", o que você irá fazer?\n"
            	 		+ "Quer desistir ou aceita decifrar o código?");
            	System.out.println("1) Sim, decifrar o código");
                System.out.println("2) Não, quero desistir");
                System.out.print("Escolha uma opção: ");
                res2 = input.nextInt();
                if (res2 < 1 || res2 > 2) {
                	System.out.print ("\nOpção inválida!\n"
                			+ "Escolha a opção 1 ou 2 e aperte 'Enter'!\n");
                }
            } while (res2 < 1 || res2 > 2);
            if (res2 == 1) {
                System.out.println("\nParabéns por sua coragem candidato! Você aceitou continuar!");
                System.out.println("Agora decifre o código que libera o LUZOX\n");
                // o jogador terá 3 tentativas. Uso d laço do/while fara esse controle
                do {
                	ArrayList alternativas = new ArrayList();
                	
                	alternativas.add("Racional");
                	alternativas.add("Inteiro"); //resposta correta!
                	alternativas.add("Racional, maior que 50");
                	alternativas.add("Natural, menor que 20");
                	alternativas.add("Não real");

                	Collections.shuffle(alternativas);
                	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                    System.out.println("\nO Valor da expressão: 8,52 + 2,4 * 5,2. Obtém como resultado um número:");
                    System.out.println("a) " +  alternativas.get(0));
                    System.out.println("b) " +  alternativas.get(1));
                    System.out.println("c) " +  alternativas.get(2));
                    System.out.println("d) " +  alternativas.get(3));
                    System.out.println("e) " +  alternativas.get(4));
                    System.out.print("Escolha uma opção: ");
                    code1 = input.next();               
                    //após a escolha da resposta, testamos caso por caso, para saber se a alternativa escolhida está correta!
                    switch (code1) {
                    case "a":
                    case "A":
                    	if (alternativas.get(0).equals("Inteiro")) {
                    		ok = 1;
                    		}
                        break;
                    case "b":
                    case "B":
                    	if (alternativas.get(1).equals("Inteiro")) {
                    		ok = 1;
                    		}
                        break;
                    case "c":
                    case "C":
                    	if (alternativas.get(2).equals("Inteiro")) {
                    		ok = 1;
                    		}
                        break;
                    case "d":
                    case "D":
                    	if (alternativas.get(3).equals("Inteiro")) {
                    		ok = 1;
                    		}
                        break;
                    case "e":
                    case "E":
                    	if (alternativas.get(4).equals("Inteiro")) {
                    		ok = 1;
                    		}
                        break;
                        default:
                            System.out.println("\nOpção inválida!");
                    }
                    i1++;
                    if (i1 == 1 && ok != 1) {
                    	System.out.println("\nAlternativa Errada!\n\n"
                        		+ ">>> Dica <<<\n"
                        		+ "1. Lembre-se, nem toda expressão de números Irracionais resulta em um número Irracional.");
                    } else if (i1 == 2 && ok != 1) {
                    	System.out.println("\nAlternativa Errada!\n\n"
                        		+ ">>> Dica <<<\n"
                        		+ "1. Lembre-se, nem toda expressão de números Irracionais resulta em um número Irracional.\n"
                        		+ "2. Nessa expressão a multiplicação deve ser a primeira operação a ser resolvida.");
                    }
                } while (i1 < 3 && ok != 1);
                if (ok == 1) {
                	System.out.println("\nParabéns, você acertou!");
                    System.out.println(nomeJogador + ", você tem um bom conhecimento em Expressões e Conjuntos númericos.");
                    System.out.println("Você resolveu o código então o LUZOX está liberado!\n");
                    System.out.println("Ao segurar o machado você percebe que em sua base está escrito: ");
                    System.out.println("Você só terá uma chance de golpear a ROBOBRA. Decifre o código e receberá uma dica de onde acertar o golpe fatal.");
                    do {
                    	System.out.println("Vamos lá " + nomeJogador + ". Quer decifrar o código e receber a dica?");
                        System.out.println("1) Sim\n2) Não");
                        System.out.print("Escolha uma opção: ");
                        res3 = input.nextInt();
                        if (res3 < 1 || res3 > 2) {
                        	System.out.print ("\nOpção inválida!\n"
                        			+ "Escolha a opção 1 ou 2 e aperte 'Enter'!\n");
                        }
                    } while (res3 < 1 || res3 > 2);
                    //Caso o jogador aceite a Dica
                    if (res3 == 1) {
                        do {
                        	ArrayList alternativas = new ArrayList();
                        	
                        	alternativas.add("2");
                        	alternativas.add("3");
                        	alternativas.add("4"); //resposta correta!
                        	alternativas.add("5");
                        	alternativas.add("6");

                        	Collections.shuffle(alternativas);
                        	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                            System.out.println("\nA multiplicação 2^a x 5^b obtem como produto o número 100, sendo que a e b são número naturais. a soma de a + b é igual:");
                            System.out.println("a) " +  alternativas.get(0));
                            System.out.println("b) " +  alternativas.get(1));
                            System.out.println("c) " +  alternativas.get(2));
                            System.out.println("d) " +  alternativas.get(3));
                            System.out.println("e) " +  alternativas.get(4));
                            System.out.print("Escolha uma opção: ");
                            code2 = input.next();               
                            //após a escolha da resposta, testamos caso por caso, para saber se a alternativa escolhida está correta!
                            switch (code2) {
                            case "a":
                            case "A":
                            	if (alternativas.get(0).equals("4")) {
                            		ok1 = 1;
                            		}
                                break;
                            case "b":
                            case "B":
                            	if (alternativas.get(1).equals("4")) {
                            		ok1 = 1;
                            		}
                                break;
                            case "c":
                            case "C":
                            	if (alternativas.get(2).equals("4")) {
                            		ok1 = 1;
                            		}
                                break;
                            case "d":
                            case "D":
                            	if (alternativas.get(3).equals("4")) {
                            		ok1 = 1;
                            		}
                                break;
                            case "e":
                            case "E":
                            	if (alternativas.get(4).equals("4")) {
                            		ok1 = 1;
                            		}
                                break;
                                default:
                                    System.out.println("\nOpção inválida!");
                            }
                            i2++;
                            if (i2 == 1 && ok1 != 1) {
                            	System.out.println("\nAlternativa Errada!\n\n"
                                		+ ">>> Dica <<<\n"
                                		+ "1. Lembre-se que quando temos potência o número é multiplicado por ele mesmo, de acordo com o exponente.");
                            } else if (i2 == 2 && ok1 != 1) {
                            	System.out.println("\nAlternativa Errada!\n\n"
                                		+ ">>> Dica <<<\n"
                                		+ "1. Lembre-se que quando temos potência o número é multiplicado por ele mesmo, de acordo com o exponente.\n"
                                		+ "2. Após descobrir as potências some os expoentes para chegar em no resultado.");
                            }
                        } while (i2 < 3 && ok1 != 1);
                        if (ok1 == 1) {
                            System.out.println("\nParabés pelo seu conhceimento em pontenciação!");
                            System.out.println("Neste momento você vai em direção a ROBOBRA e consegui acertar um golpe no rabo do animal.");
                            System.out.println("Ao atingi-la você escuta um barulho bem alto e percebe que a coisa se auto desmonta");
                            System.out.println("Mesmo depois de derrotar a criatura,as paredes ainda continuam se movendo e diminuindo seu espaço");
                            System.out.println("Você tem pouco tempo, então corre até a porta e percebe que será necessário inserir uma senha para abrir a porta ");
                            System.out.println("abaixo do teclado da senha está escrito: Decifre o código e através do resultado correto obtenha a senha para abrir a porta\n\n");
                            do {
                            	ArrayList alternativas = new ArrayList();
                            	
                            	alternativas.add("28");
                            	alternativas.add("31");
                            	alternativas.add("34");
                            	alternativas.add("35"); //resposta correta!
                            	alternativas.add("40");

                            	Collections.shuffle(alternativas);
                            	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                            	System.out.println("A senha da porta é dada por uma sequência de seis números, todos menores que 100, que obedece a determinada lógica.");
                                System.out.println("Análise a seguinte sequencia: {32,27, _ ,30,38,33} ");
                                System.out.println("a) " +  alternativas.get(0));
                                System.out.println("b) " +  alternativas.get(1));
                                System.out.println("c) " +  alternativas.get(2));
                                System.out.println("d) " +  alternativas.get(3));
                                System.out.println("e) " +  alternativas.get(4));
                                System.out.print("Escolha uma opção: ");
                                code3 = input.next();               
                                //após a escolha da resposta, testamos caso por caso, para saber se a alternativa escolhida está correta!
                                switch (code3) {
                                case "a":
                                case "A":
                                	if (alternativas.get(0).equals("35")) {
                                		ok2 = 1;
                                		}
                                    break;
                                case "b":
                                case "B":
                                	if (alternativas.get(1).equals("35")) {
                                		ok2 = 1;
                                		}
                                    break;
                                case "c":
                                case "C":
                                	if (alternativas.get(2).equals("35")) {
                                		ok2 = 1;
                                		}
                                    break;
                                case "d":
                                case "D":
                                	if (alternativas.get(3).equals("35")) {
                                		ok2 = 1;
                                		}
                                    break;
                                case "e":
                                case "E":
                                	if (alternativas.get(4).equals("35")) {
                                		ok2 = 1;
                                		}
                                    break;
                                    default:
                                        System.out.println("\nOpção inválida!");
                                }
                                i3++;
                                if (i3 == 1 && ok2 != 1) {
                                	System.out.println("\nAlternativa Errada!\n\n"
                                    		+ ">>> Dica <<<\n"
                                    		+ "1. Descubra a lógica presente na sequência.");
                                } else if (i3 == 2 && ok2 != 1) {
                                	System.out.println("\nAlternativa Errada!\n\n"
                                    		+ ">>> Dica <<<\n"
                                    		+ "1. Descubra a lógica presente na sequência.\n"
                                    		+ "2. Observe a diferença existente entre os números da sequência");
                                }
                            } while (i3 < 3 && ok2 != 1);
                            if (ok2 == 1) {
                                System.out.println("\nParabéns por seus conhecimentos matemáticos. Você passou por todos códigos.");
                                System.out.println("Você insere o código na porta a mesma se abre e você passa correndo, entrando em uma sala,");
                                System.out.println("você olha ao redor e está em uma sala com vários funcionários trabalhando, cada uma em sua mesa");
                                System.out.println("eles te olham também, batem palmas e gritam, parabéns mais um sobrevivente");
                                System.out.println("um robô te auxilia até uma sala e diz\n");
                                System.out.println("- Parabéns " + nomeJogador + " você acaba de ser contratado como ANALISTA JUNIOR, agora preciso de uma gota de sangue sua.");
                                return 1;
                            } else {
                                System.out.println("Você errou nas 3 tentivas, precisa melhorar seus conhecimentos em sequências númericas ");
                            }
                            return 2;
                            // Caso o jogador erre o código da dica
                        } else if (ok1 != 1 && i2 == 3);
                        do {
                        	System.out.println("Você deverá decidir sozinho, onde acertar a Robobra.");
                            System.out.println("Escolha em qual lugar irá acertar o golpe: ");
                            System.out.println("1) Atingi o rabo");
                            System.out.println("2) Atingir na cabeça");
                            System.out.println("3) Atingir o peito");
                            res4 = input.nextInt();
                            if(res4 < 1 || res4 > 3) {
                            	System.out.print ("\nOpção inválida!\n"
                            			+ "Escolha a opção 1, 2 ou 3 e aperte 'Enter'!\n");
                            }
                        } while (res4 < 1 || res4 > 3);
                        switch (res4) {
                            case 1:
                                r = 1;
                                break;
                            case 2:
                            case 3:
                                System.out.println("\n(x_x) MORREU (x_x)\n"
                                		+ "" + nomeJogador + " você atingiu no lugar errado.\n"
                                				+ "O ROBOBRA te derrotou!");
                                break;
                            default:
                        }
                        if (r == 1) {
                            System.out.println("Neste momento você vai em direção a ROBOBRA e consegui acertar um golpe no rabo do animal.");
                            System.out.println("Ao atingi-la você escuta um barulho bem alto e percebe que a coisa se auto desmonta");
                            System.out.println("Mesmo depois de derrotar a criatura,as paredes ainda continuam se movendo e diminuindo seu espaço");
                            System.out.println("Você tem pouco tempo, então corre até a porta e percebe que será necessário inserir uma senha para abrir a porta ");
                            System.out.println("abaixo do teclado da senha está escrito: Decifre o código e através do resultado correto obtenha a senha para abrir a porta\n\n");
                            do {
                            	ArrayList alternativas = new ArrayList();
                            	
                            	alternativas.add("28");
                            	alternativas.add("31");
                            	alternativas.add("34");
                            	alternativas.add("35"); //resposta correta!
                            	alternativas.add("40");

                            	Collections.shuffle(alternativas);
                            	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                            	System.out.println("A senha da porta é dada por uma sequência de seis números, todos menores que 100, que obedece a determinada lógica.");
                                System.out.println("Análise a seguinte sequencia: {32,27, _ ,30,38,33} ");
                                System.out.println("a) " +  alternativas.get(0));
                                System.out.println("b) " +  alternativas.get(1));
                                System.out.println("c) " +  alternativas.get(2));
                                System.out.println("d) " +  alternativas.get(3));
                                System.out.println("e) " +  alternativas.get(4));
                                System.out.print("Escolha uma opção: ");
                                code5 = input.next();               
                                //após a escolha da resposta, testamos caso por caso, para saber se a alternativa escolhida está correta!
                                switch (code5) {
                                case "a":
                                case "A":
                                	if (alternativas.get(0).equals("35")) {
                                		ok5 = 1;
                                		}
                                    break;
                                case "b":
                                case "B":
                                	if (alternativas.get(1).equals("35")) {
                                		ok5 = 1;
                                		}
                                    break;
                                case "c":
                                case "C":
                                	if (alternativas.get(2).equals("35")) {
                                		ok5 = 1;
                                		}
                                    break;
                                case "d":
                                case "D":
                                	if (alternativas.get(3).equals("35")) {
                                		ok5 = 1;
                                		}
                                    break;
                                case "e":
                                case "E":
                                	if (alternativas.get(4).equals("35")) {
                                		ok5 = 1;
                                		}
                                    break;
                                    default:
                                        System.out.println("\nOpção inválida!");
                                }
                                t1++;
                                if (t1 == 1 && ok5 != 1) {
                                	System.out.println("\nAlternativa Errada!\n\n"
                                    		+ ">>> Dica <<<\n"
                                    		+ "1. Descubra a lógica presente na sequência.");
                                } else if (t1 == 2 && ok5 != 1) {
                                	System.out.println("\nAlternativa Errada!\n\n"
                                    		+ ">>> Dica <<<\n"
                                    		+ "1. Descubra a lógica presente na sequência.\n"
                                    		+ "2. Observe a diferença existente entre os números da sequência");
                                }
                            } while (t1 < 3 && ok5 != 1);
                            if (ok5 == 1) {
                                System.out.println("\nParabéns por seus conhecimentos na matéria de matemática.");
                                System.out.println("\nVocê insere o código na porta a mesma se abre e você passa correndo, entrando em uma sala,");
                                System.out.println("você olha ao redor e está em uma sala com vários funcionários trabalhando, cada uma em sua mesa");
                                System.out.println("eles te olham também, batem palmas e gritam, parabéns mais um sobrevivente");
                                System.out.println("um robô te auxilia até uma sala e diz");
                                System.out.println("Parabéns " + nomeJogador + " você acaba de ser contratado como ANALISTA JUNIOR, agora preciso de uma gota de sangue sua.");
                                return 1;
                            } else {
                                System.out.println("\n(x_x) MORREU (x_x)\n"
                                		+ "Você errou nas 3 tentivas.\nPrecisa melhorar seus conhecimentos em sequencias númericas\n");
                            }
                            return 2;
                        } else {
                            System.out.println("\n(x_x) MORREU (x_x)\n");
                        }
                        return 2;
                        //Caso o jogador não aceite a dica de onde atingir a ROBOBRA.
                    } else if (res3 == 2);
                    do {
                    	System.out.println("Você não aceitou a dica. Deverá decidir onde golpear o ROBOBRA.");
                        System.out.println("Escolha onde irá acertar o golpe:");
                        System.out.println("1) Atingi o rabo");
                        System.out.println("2) Atingir na cabeça");
                        System.out.println("3) Atingir o peito");
                        System.out.print("Escolha uma opção: ");
                        res4 = input.nextInt();
                        if(res4 < 1 || res4 > 3) {
                        	System.out.print ("\nOpção inválida!\n"
                        			+ "Escolha a opção 1, 2 ou 3 e aperte 'Enter'!\n");
                        }
                    } while (res4 < 1 || res4 > 3);
                    switch (res4) {
                        case 1:
                            r = 1;
                            break;
                        case 2:
                        case 3:
                        	System.out.println("\n(x_x) MORREU (x_x)\n"
                            		+ "" + nomeJogador + " você atingiu no lugar errado.\n"
                            				+ "O ROBOBRA te derrotou!");
                            break;
                        default:
                    }
                    if (r == 1) {
                        System.out.println("Neste momento você vai em direção a RBOBRA e consegui acertar um golpe no rabo do animal.");
                        System.out.println("Ao atingi-la você escuta um barulho bem alto e percebe que a coisa se auto desmonta");
                        System.out.println("Mesmo depois de derrotar a criatura,Vas paredes ainda continuam se movendo e diminuindo seu espaço");
                        System.out.println("Você tem pouco tempo, então corre até a porta e percebe que será necessário inserir uma senha para abrir a porta ");
                        System.out.println("abaixo do teclado da senha está escrito: Decifre o código e através do resultado correto obtenha a senha para abrir a porta");
                        System.out.println("");
                        do {
                        	ArrayList alternativas = new ArrayList();
                        	
                        	alternativas.add("28");
                        	alternativas.add("31");
                        	alternativas.add("34");
                        	alternativas.add("35"); //resposta correta!
                        	alternativas.add("40");

                        	Collections.shuffle(alternativas);
                        	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                        	System.out.println("A senha da porta é dada por uma sequência de seis números, todos menores que 100, que obedece a determinada lógica.");
                            System.out.println("Análise a seguinte sequencia: {32,27, _ ,30,38,33} ");
                            System.out.println("a) " +  alternativas.get(0));
                            System.out.println("b) " +  alternativas.get(1));
                            System.out.println("c) " +  alternativas.get(2));
                            System.out.println("d) " +  alternativas.get(3));
                            System.out.println("e) " +  alternativas.get(4));
                            System.out.print("Escolha uma opção: ");
                            code4 = input.next();               
                            //após a escolha da resposta, testamos caso por caso, para saber se a alternativa escolhida está correta!
                            switch (code4) {
                            case "a":
                            case "A":
                            	if (alternativas.get(0).equals("35")) {
                            		ok4 = 1;
                            		}
                                break;
                            case "b":
                            case "B":
                            	if (alternativas.get(1).equals("35")) {
                            		ok4 = 1;
                            		}
                                break;
                            case "c":
                            case "C":
                            	if (alternativas.get(2).equals("35")) {
                            		ok4 = 1;
                            		}
                                break;
                            case "d":
                            case "D":
                            	if (alternativas.get(3).equals("35")) {
                            		ok4 = 1;
                            		}
                                break;
                            case "e":
                            case "E":
                            	if (alternativas.get(4).equals("35")) {
                            		ok4 = 1;
                            		}
                                break;
                                default:
                                    System.out.println("\nOpção inválida!");
                            }
                            t++;
                            if (t == 1 && ok4 != 1) {
                            	System.out.println("\nAlternativa Errada!\n\n"
                                		+ ">>> Dica <<<\n"
                                		+ "1. Descubra a lógica presente na sequência.");
                            } else if (t == 2 && ok4 != 1) {
                            	System.out.println("\nAlternativa Errada!\n\n"
                                		+ ">>> Dica <<<\n"
                                		+ "1. Descubra a lógica presente na sequência.\n"
                                		+ "2. Observe a diferença existente entre os números da sequência");
                            }
                        } while (t < 3 && ok4 != 1);
                        System.out.println("");
                        if (ok4 == 1) {
                            System.out.println("Parabéns por seus conhecimentos matemáticos. Você passou por todos códigos");
                            System.out.println("Você insere o código na porta a mesma se abre e você passa correndo, entrando em uma sala,");
                            System.out.println("você olha ao redor e está em uma sala com vários funcionários trabalhando, cada uma em sua mesa");
                            System.out.println("eles te olham também, batem palmas e gritam, parabéns mais um sobrevivente");
                            System.out.println("um robô te auxilia até uma sala e diz");
                            System.out.println("");
                            System.out.println("Parabéns " + nomeJogador + " você acaba de ser contratado como ANALISTA JUNIOR, agora preciso de uma gota de sangue sua.");
                            return 1;
                        } else {
                            System.out.println("\n(x_x) MORREU (x_x)\n"
                            		+ "Você errou nas 3 tentativas.\n"
                            		+ "Precisa melhorar seu conhecimento em sequencias númericas.\n");
                        }
                        return 2;
                    } else {
                        System.out.println("\n(x_x) MORREU (x_x)\n");
                    }
                    return 2;
                } else {
                    System.out.println("\n(x_x) MORREU (x_x)\n"
                    		+ "Você errou nas 3 tentativas.\n"
                    		+ "Precisa melhorar seus conhecimentos em expressões e Cojuntos númericos");
                }
                return 2;
            } else {
            	System.out.println("\n(+_+) FRACO (+_+)\n"
                		+ "" + nomeJogador + " você desistiu!\n"
                				+ "Fim do jogo.");
            }
            return 2;
        } else {
        	System.out.println("\n(+_+) FRACO (+_+)\n"
            		+ "" + nomeJogador + " você desistiu!\n"
            				+ "Fim do jogo.");
        }
        return 2;
    }

    static int caminhoAnalistaP(String per) {
        int cam1, cam2, cam3, caixa1, caixa2, mata, i = 1, j = 1, k = 1, l = 1, certo = 0, certo1 = 0, certo2 = 0, certo3 = 0;
        String res1, res2, resc1, resc2;
        System.out.println("\nVocê acertou o código e imediatamente a porta é liberada. Você passa correndo pois a sala esta com muita água, passando pela porta rapidamente\n"
        		+ "a mesma se fecha deixando a proxima sala toda escura. De repente as luzes se ascendem e você se depara com um labirinto, você percebe que sua única saída\n"
        		+ "e atravessa-ló, ao dar o primeiro passo você passa outra vez por uma luz infravermelha e então o labirinto começa a se encher de gás tóxico e em poucos\n"
        		+ "minutos você irá morrer, você percebe que precisa sair dalí rápido.");
        do {
            System.out.println("\nVocê pode sair pela esquerda ou pela direita qual saída você escolhe?");
            System.out.println("1) Esquerda\n2) Direita");
            System.out.print("Escolha uma opção: ");
            cam1 = input.nextInt();
            //saída certa pela esquerda
            if (cam1 == 2) {
                System.out.println("Você segue pela saída do lado direito, anda por 5 minutos até se deparar com uma mensagem escrita em uma porta:");
                System.out.println("--- Você está no caminho errado, volte e saia pela esquerda ---\n"
                		+ "Então você volta correndo por que o gás está cada vez mais forte.");
            }
        } while (cam1 == 2);

        System.out.println("Agora seguindo pela saída do lado esquerdo você anda até se deparar com um robô ele está parado impedindo a passagem,\n"
        		+ "você tenta tira-lo do lugar porém ele é muito pesado, então você percebe um código em sua cabeça e em seu peito está escrito:\n"
        		+ "--- Decifre o código e o robô se desmontará sozinho ---\n");
        System.out.println("Você quer decifrar o codigo? \n1 - Sim\n2 - Não");
        cam2 = input.nextInt();

        if (cam2 == 1) {
            do {
            	ArrayList alternativas = new ArrayList();
            	
            	alternativas.add("0"); //resposta correta!
            	alternativas.add("6");
            	alternativas.add("-1");
            	alternativas.add("-18");
            	alternativas.add("-6");

            	Collections.shuffle(alternativas);
            	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
            	System.out.println("Na função f(x) = -3x + 18, qual é o valor de f(x) quando x = 6?");
                System.out.println("a) " +  alternativas.get(0));
                System.out.println("b) " +  alternativas.get(1));
                System.out.println("c) " +  alternativas.get(2));
                System.out.println("d) " +  alternativas.get(3));
                System.out.println("e) " +  alternativas.get(4));
                System.out.print("Escolha uma opção: ");
                res1 = input.next();
                switch (res1) {
                case "a":
                case "A":
                	if (alternativas.get(0).equals("0")) {
                		certo = 1;
                		}
                    break;
                case "b":
                case "B":
                	if (alternativas.get(1).equals("0")) {
                		certo = 1;
                		}
                    break;
                case "c":
                case "C":
                	if (alternativas.get(2).equals("0")) {
                		certo = 1;
                		}
                    break;
                case "d":
                case "D":
                	if (alternativas.get(3).equals("0")) {
                		certo = 1;
                		}
                    break;
                case "e":
                case "E":
                	if (alternativas.get(4).equals("0")) {
                		certo = 1;
                		}
                    break;
                    default:
                        System.out.println("\nOpção inválida!");
                }
                if (i == 1 && certo != 1) {
                	System.out.println("\nAlternativa Errada!\n\n"
                    		+ ">>> Dica <<<\n"
                    		+ "1. Substitua a incógnita x pelo valor indicado.");
                } else if (i == 2 && certo != 1) {
                	System.out.println("\nAlternativa Errada!\n\n"
                    		+ ">>> Dica <<<\n"
                    		+ "1. Substitua a incógnita x pelo valor indicado.\n"
                    		+ "2. Realize primerio a multiplicação.");
                }
                i++;
            } while (i <= 3 && certo != 1);
            //  i, j, k, l começa com 1, vamos estabelecer 3 dicas para cada pergunta.
            if (certo != 1) {
                System.out.println("\n(x_x) MORREU (x_x)\n"
                		+ "" + nomeJogador + " você precisa estudar mais funções de 1º grau.");
                return 2;
            } else {
                System.out.println("Parabéns " + nomeJogador + " você está indo bem na matéria de funções de 1º grau.");
            }
            System.out.println("\nO robô se desmonta por inteiro e você consegue prosseguir no labirinto,");
            System.out.println("então você segue e se depara com uma porta que tem escrito uma mensagem");
            System.out.println("----- Decifre o código para liberar a porta ----");
            System.out.println("Você quer decifrar o código?\n1) Sim\n2) Não");
            System.out.print("Escolha uma opção: ");
            cam3 = input.nextInt();
            if (cam3 == 1) {
                do {
                	ArrayList alternativas = new ArrayList();
                	
                	alternativas.add("-3, 3"); //resposta correta!
                	alternativas.add("2, -3");
                	alternativas.add("-3, 1");
                	alternativas.add("-1, -2");
                	alternativas.add("-2, 4");

                	Collections.shuffle(alternativas);
                	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                	System.out.println("Na função f(x) = 2x - 15, qual é o valor de f(x) quando x = 6 e x = 9?");
                    System.out.println("a) " +  alternativas.get(0));
                    System.out.println("b) " +  alternativas.get(1));
                    System.out.println("c) " +  alternativas.get(2));
                    System.out.println("d) " +  alternativas.get(3));
                    System.out.println("e) " +  alternativas.get(4));
                    System.out.print("Escolha uma opção: ");
                    res2 = input.next();
                    switch (res2) {
                    case "a":
                    case "A":
                    	if (alternativas.get(0).equals("-3, 3")) {
                    		certo = 1;
                    		}
                        break;
                    case "b":
                    case "B":
                    	if (alternativas.get(1).equals("-3, 3")) {
                    		certo = 1;
                    		}
                        break;
                    case "c":
                    case "C":
                    	if (alternativas.get(2).equals("-3, 3")) {
                    		certo = 1;
                    		}
                        break;
                    case "d":
                    case "D":
                    	if (alternativas.get(3).equals("-3, 3")) {
                    		certo = 1;
                    		}
                        break;
                    case "e":
                    case "E":
                    	if (alternativas.get(4).equals("-3, 3")) {
                    		certo = 1;
                    		}
                        break;
                        default:
                            System.out.println("\nOpção inválida!");
                    }
                    if (j == 1 && certo1 != 1) {
                    	System.out.println("\nAlternativa Errada!\n\n"
                        		+ ">>> Dica <<<\n"
                        		+ "1. Substitua a incógnita x pelo valor indicado.");
                    } else if (j == 2 && certo1 != 1) {
                    	System.out.println("\nAlternativa Errada!\n\n"
                        		+ ">>> Dica <<<\n"
                        		+ "1. Substitua a incógnita x pelo valor indicado.\n"
                        		+ "2. Realize primerio a multiplicação.");
                    }
                    j++;
                } while (j <= 3 && certo1 != 1);
                if (certo1 != 1) {
                    System.out.println("\n(x_x) MORREU (x_x)\n"
                    		+ "" + nomeJogador + " você precisa estudar mais funções de 1º grau!");
                    return 2;
                } else {
                    System.out.println("Parabéns" + nomeJogador + " você está indo bem na matéria de funções de 1º grau!\n");
                }          
                System.out.println("A porta se abre e você continua o labirinto, você passa por algumas caixas e sem entender o que são continua o caminho, e então você se depara\n"
                		+ " com uma aranha gigante ela não é uma aranha comum é uma aranha robô a ROBORANHA,  ela está soltando raios lazer como se fossem teias, você fica\n"
                		+ "desesperado, mas então pensa que algo nas caixas que você encontrou no caminho podem te ajudar.");
                System.out.println("Você volta, e vai até a primeira caixa, você a abre e dentro dela tem um código e um botão vermelho");
                do {
                	System.out.println("Você quer decifrar o código?\n1) Sim\n2) Não");
                	System.out.print("Escolha uma opção: ");
                    caixa1 = input.nextInt();
                    if (caixa1 < 1 || caixa1 > 2) {
                    	System.out.print ("\nOpção inválida!\n"
                    			+ "Escolha a opção 1 ou 2 e aperte 'Enter'!\n");
                    }
                } while (caixa1 < 1 || caixa1 > 2);
                if (caixa1 == 1) {
                    do {
                    	ArrayList alternativas = new ArrayList();
                    	
                    	alternativas.add("1, decrescente");
                    	alternativas.add("1, crescente"); //resposta correta!
                    	alternativas.add("2, crescente");
                    	alternativas.add("2, decrescente");
                    	alternativas.add("-2, crescente");

                    	Collections.shuffle(alternativas);
                    	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                    	System.out.println("Na função f(x) = 2^x qual valor de f(x) quando X for 0? E a função será cescente ou decrescente?");
                        System.out.println("a) " +  alternativas.get(0));
                        System.out.println("b) " +  alternativas.get(1));
                        System.out.println("c) " +  alternativas.get(2));
                        System.out.println("d) " +  alternativas.get(3));
                        System.out.println("e) " +  alternativas.get(4));
                        System.out.print("Escolha uma opção: ");
                        resc1 = input.next();
                        switch (resc1) {
                        case "a":
                        case "A":
                        	if (alternativas.get(0).equals("1, crescente")) {
                        		certo2 = 1;
                        		}
                            break;
                        case "b":
                        case "B":
                        	if (alternativas.get(1).equals("1, crescente")) {
                        		certo2 = 1;
                        		}
                            break;
                        case "c":
                        case "C":
                        	if (alternativas.get(2).equals("1, crescente")) {
                        		certo2 = 1;
                        		}
                            break;
                        case "d":
                        case "D":
                        	if (alternativas.get(3).equals("1, crescente")) {
                        		certo2 = 1;
                        		}
                            break;
                        case "e":
                        case "E":
                        	if (alternativas.get(4).equals("1, crescente")) {
                        		certo2 = 1;
                        		}
                            break;
                            default:
                                System.out.println("\nOpção inválida!");
                        }
                        if (k == 1 && certo2 != 1) {
                        	System.out.println("\nAlternativa Errada!\n\n"
                            		+ ">>> Dica <<<\n"
                            		+ "1. Substitua a incógnita x pelo valor indicado e realize a potenciação.");
                        } else if (k == 2 && certo2 != 1) {
                        	System.out.println("\nAlternativa Errada!\n\n"
                            		+ ">>> Dica <<<\n"
                            		+ "1. Substitua a incógnita x pelo valor indicado e realize a potenciação.\n"
                            		+ "2. Quando a > 0 a função é crescente e quando a < 0 a função é decrescente.");
                        }
                        k++;
                    } while (k <= 3 && certo2 != 1);
                    if (certo2 != 1) {
                        System.out.println("\n(x_x) MORREU (x_x)\n"
                        		+ "" + nomeJogador + " você precisa estudar mais funções exponenciais.");
                        return 2;
                    } else {
                        System.out.println("\nParabéns " + nomeJogador + " você está indo bem na matéria de funções exponenciais.\n");
                    }
                    System.out.println("A caixa se desmonta sozinha deixando sobre sua mão um papel e aparentemente um peça de uma arma,\n"
                    		+ "neste papel tem uma dica para ser usado na proxima caixa.\n");
                    System.out.println("--- Os valores da vértice da parábola do próximo defasio, são positivos! ---");
                    System.out.println("\nVocê já está ficando cansado e tonto, mas falta somente mais uma caixa para você descobrir como faz para passar\n"
                    		+ "pela ROBORANHA e tentar sair do labirinto. Então você caminha até a outra caixa, a abre e vê outro código a ser decifrado.");
                    do {
                    	System.out.println("\nVocê quer decifrar o código?\n1) Sim\n2) Não");
                    	System.out.print("Escolha uma opção: ");
                        caixa2 = input.nextInt();
                        if (caixa2 < 1 || caixa2 > 2) {
                        	System.out.print ("\nOpção inválida!\n"
                        			+ "Escolha a opção 1 ou 2 e aperte 'Enter'!\n");
                        }
                    } while (caixa2 < 1 || caixa2 > 2);
                    if (caixa2 == 1) {
                        do {
                        	ArrayList alternativas = new ArrayList();
                        	
                        	alternativas.add("4, -4");
                        	alternativas.add("-2, 0");
                        	alternativas.add("-2, 2");
                        	alternativas.add("2, 4");
                        	alternativas.add("2, 2"); //resposta correta!

                        	Collections.shuffle(alternativas);
                        	//sempre que jogado outra vez ou feito mais de 1 tentativa de resposta, as alternativas irão ser embaralhadas, sempre aparecendo em um lugar diferente!
                        	System.out.println("O vértice da parábola que corresponde a função Y = (x - 2)^2 + 2 é?");
                            System.out.println("Você já sabe que a alternativa correta possui números positivos.");
                            System.out.println("a) " +  alternativas.get(0));
                            System.out.println("b) " +  alternativas.get(1));
                            System.out.println("c) " +  alternativas.get(2));
                            System.out.println("d) " +  alternativas.get(3));
                            System.out.println("e) " +  alternativas.get(4));
                            System.out.print("Escolha uma opção: ");
                            resc1 = input.next();
                            switch (resc1) {
                            case "a":
                            case "A":
                            	if (alternativas.get(0).equals("2, 2")) {
                            		certo2 = 1;
                            		}
                                break;
                            case "b":
                            case "B":
                            	if (alternativas.get(1).equals("2, 2")) {
                            		certo2 = 1;
                            		}
                                break;
                            case "c":
                            case "C":
                            	if (alternativas.get(2).equals("2, 2")) {
                            		certo2 = 1;
                            		}
                                break;
                            case "d":
                            case "D":
                            	if (alternativas.get(3).equals("2, 2")) {
                            		certo2 = 1;
                            		}
                                break;
                            case "e":
                            case "E":
                            	if (alternativas.get(4).equals("2, 2")) {
                            		certo2 = 1;
                            		}
                                break;
                                default:
                                    System.out.println("\nOpção inválida!");
                            }
                            if (l == 1 && certo3 != 1) {
                            	System.out.println("\nAlternativa Errada!\n\n"
                                		+ ">>> Dica <<<\n"
                                		+ "1. Elimine primeiro os parentesês e organize a equação.");
                            } else if (l == 2 && certo3 != 1) {
                            	System.out.println("\nAlternativa Errada!\n\n"
                                		+ ">>> Dica <<<\n"
                                		+ "1. Elimine primeiro os parentesês e organize a equação.\n"
                                		+ "2. Use as fórmulas para descobrir o vértice, primeiro descubra o delta, utilize Bhaskara.");
                            }
                            l++;
                        } while (l <= 3 && certo3 != 1);
                        if (certo3 != 1) {
                            System.out.println("\n(x_x) MORREU (x_x)\n"
                            		+ "" + nomeJogador + " você precisa estudar mais funções de 2º grau.");
                            return 2;
                        } else {
                            System.out.println("Parabéns " + nomeJogador + " você está indo bem na matéria de funções de 2º grau.\n");
                            System.out.println("A caixa se desmonta sozinha deixando em sua mão uma outra peça, não leva muito tempo você percebe que\n"
                            		+ "precisa encaixar uma peça na outra, fazendo isso você percebe que montou uma espécie de arma a lazer, ao encaixar\n"
                            		+ "uma na outra você vê que aparece uma mensagem no centro desta arma escrito:");
                            System.out.println("\n--- Aperte o botão na parte central da arma LEIZARRU e mire o lazer no coração da ROBORANHA ---\n");
                            do {
                            	System.out.println("Você que ir até a aranha robô e mata-lá?\n1) Sim\n2) Não");
                            	System.out.print("Escolha uma opção: ");
                                mata = input.nextInt();
                                if (mata < 1 || mata > 2) {
                                	System.out.print ("\nOpção inválida!\n"
                                			+ "Escolha a opção 1 ou 2 e aperte 'Enter'!\n");
                                }
                            } while (mata < 1 || mata > 2);
                            if (mata == 1) {
                                System.out.println("Você vai até a ROBORANHA acerta o lazer no seu coração e a mata ela se desmonta inteira liberando assim o caminho,\n"
                                		+ "você percorre mais um pouco o labirinto e chega até uma porta você corre para abri-la e para sua surpresa ela esta destrancada,\n"
                                		+ "olhando ao redor você percebe que está em uma sala com vários funcionários trabalhando, cada uma em sua mesa eles te olham também,\n"
                                		+ "começam a bater palmas e gritam, parabéns mais um sobrevivente!");
                                System.out.println("Um robô te auxilia até uma sala e diz:");
                                System.out.println("- Parabéns " + nomeJogador + " você acaba de ser contratado como ANALISTA PLENO, agora preciso de uma gota de sangue sua. ");
                                return 1;
                            } else {
                                System.out.println("\n(x_x) MORREU (x_x)\n"
                                		+ "" + nomeJogador + " ocê escolheu não matar a ROBORANHA.\n" 
                                		+ "Ela se ativa e com um único golpe te mata!");
                                return 2;
                            }
                            // se o candidato escolher não decifrar os códigos ele morre e o jogo volta ao menu.
                        }
                    } else {
                        System.out.println("\n(x_x) MORREU (x_x)\n"
                        		+ "" + nomeJogador + " você escolheu não decifrar o código.");
                        return 2;
                    }
                } else {
                	System.out.println("\n(x_x) MORREU (x_x)\n"
                    		+ "" + nomeJogador + " você escolheu não decifrar o código.");
                    return 2;
                }
            } else {
                System.out.println("\n(x_x) MORREU (x_x)\n"
                		+ "" + nomeJogador + " você escolheu não decifrar o código acabou morrendo dentro da sala.");
                return 2;
            }
        } else {
            System.out.println("\n(x_x) MORREU (x_x)\n"
            		+ "Você escolheu não decifrar o código e o ambiente se encheu de gás."
            		+ "Você morreu entoxicado!");
            return 2;
        }
    }
}